

#include <p18f4520.h>
#include "PIDFunctions.h"

#define	ERRORmax        0x0FA0	//setting my MAX ERROR (4000d)

#define KI_INIT         0x00   //numbers from manual tuning                    
#define KD_INIT         0x02 
#define KP_INIT         0x01




volatile unsigned char ERRORflag = 0; //Error flag

volatile struct PIDdata LEFTwheel;        
volatile struct PIDdata RIGHTwheel;
volatile struct PIDgains PIDgainsLEFT;        
volatile struct PIDgains PIDgainsRIGHT;


//Takes set speed and current speed, calculates error values
void PIDerror(struct PIDdata *myPID)
{
    myPID->ERRORcurrent= (int) myPID->SPEEDset  -  myPID->SPEEDcurrent;
    
    //This saves going into the next function to recalcualte PID value
    if (myPID->ERRORcurrent == 0)
    {             
        ERRORflag = 0;              // set error zero flag CAN BE USED TO MAKE CODE LESS INTENSIVE
    }
    else
    {
        ERRORflag = 1;
    }
    
    
    myPID->ERRORaccum+=myPID->ERRORcurrent; //accumulating error

    if (myPID->ERRORaccum > ERRORmax ) //Is checking error within bounds, sets to max error
    {        // calculate accumulated error
        myPID->ERRORaccum = ERRORmax ;
    }

    myPID->ERRORdiff = myPID->ERRORcurrent - myPID->ERRORlast;  // calc delta error
    myPID->ERRORlast = myPID->ERRORcurrent;      // set previous error to current error for next round
   

 }


//Takes error values and calculates new PWM
void  PIDoutputPWM(struct PIDdata *pwmPID, struct PIDgains PIDgains )
{
    signed int propTEMP;    //proportional error
    signed int interTEMP;   //intergral error
    signed int derivTEMP;   //derivaite error

    propTEMP = PIDgains.Kp * pwmPID->ERRORcurrent  ;
    interTEMP = PIDgains.Ki * pwmPID->ERRORaccum ;
    derivTEMP = PIDgains.Kd * pwmPID->ERRORdiff  ;
        
    //Setting our new PWM output
    pwmPID->PIDoutput += propTEMP+interTEMP+derivTEMP;
        
    //checking bounds for the PWMoutput
    if((pwmPID->PIDoutput) > 0xFF)  
    {
        pwmPID->PIDoutput=0xFF;
    }
    else if((pwmPID->PIDoutput) < 0)
    {
        pwmPID->PIDoutput=0;
            
    }

}



void PIDinitialise(void)
{
    
    //Initialising PID vars for LEFT and RIGHT wheels
    LEFTwheel.ERRORaccum=0;
    LEFTwheel.ERRORcurrent=0;
    LEFTwheel.ERRORdiff=0;
    LEFTwheel.ERRORlast=0;
    LEFTwheel.PIDoutput=0;
    LEFTwheel.SPEEDcurrent=0;
    LEFTwheel.SPEEDset=0;
    LEFTwheel.Direction=0;
    
    RIGHTwheel.ERRORaccum=0;
    RIGHTwheel.ERRORcurrent=0;
    RIGHTwheel.ERRORdiff=0;
    RIGHTwheel.ERRORlast=0;
    RIGHTwheel.PIDoutput=0;
    RIGHTwheel.SPEEDcurrent=0;
    RIGHTwheel.SPEEDset=0;
    RIGHTwheel.Direction = 0;
    
    //Initialsing Gains for LEFT and RIGHT wheels
    PIDgainsLEFT.Kd  =  KD_INIT;
    PIDgainsLEFT.Ki  =  KI_INIT;
    PIDgainsLEFT.Kp  =  KP_INIT;
    
    PIDgainsRIGHT.Kd =  KD_INIT;
    PIDgainsRIGHT.Ki =  KI_INIT;
    PIDgainsRIGHT.Kp =  KP_INIT;     
    
    
    
}
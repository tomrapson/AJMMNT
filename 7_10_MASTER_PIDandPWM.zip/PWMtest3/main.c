
/*Include Files*/
#include <p18f4520.h>
#include "ConfigRegs18f4520.h"
#include "main.h"
#include "IoDefs.h"
#include "PIDFunctions.h"
#include "MotorInputDefs.h"
#include "SerialStuff.h"
#include <stdio.h>     
#include <stdlib.h>
#include <adc.h>


unsigned char direction = FORWARD;  //TAKE THIS OUT LATER


/*

//INTERUPT SERVICE ROUTINES
//THE ISRs DONT DO ANYTHING AT THE MOMENT
#pragma code highPriorityInterruptAddress=0x0008
void high_interrupt()
{
    highPriorityIsr();
}

#pragma code lowPriorityInterruptAddress=0x0018
void low_interrupt()
{
    lowPriorityIsr();
}

#pragma code

#pragma interrupt highPriorityIsr
void highPriorityIsr()
{    
    //get IR sensor readings
    //Get encoder values
    //Check serial buffer
    
}

#pragma interruptlow lowPriorityIsr
void lowPriorityIsr()
{
    //Send stuff over serial
    //Scan for parrot??
}


*/






//THIS IS THE MAIN LOOP
void main(void)
{   
       
    setup();
    
    //FOR TESTING
    RIGHTspeed = 200;
    LEFTspeed = 200;
    
    //SENDdataID ='b';
    //SENDserialPACKAGE();
           
    //MAIN
    while(1)
    { 
            
        
        //Takes values from 0-255 negative MAX speed to positive MAX speed
        //and output magnitude for encoders, with direction
        SCALEspeed(RIGHTspeed,RIGHTWHEEL,&RIGHTwheel);
        SCALEspeed(LEFTspeed,LEFTWHEEL,&LEFTwheel);
        
        //PID calculation stuff (FINDS ERROR)
        PIDerror(&LEFTwheel);
        PIDerror(&RIGHTwheel);
        
        //IF ERROR (if there is a difference between set and current, change motor speed)
        if (ERRORflag==1){
            
            //Calculates change in PWM based off error
            PIDoutputPWM(&LEFTwheel, PIDgainsLEFT );//Gets passed a pointer and a copy (copy for safeguard))
            PIDoutputPWM(&RIGHTwheel, PIDgainsRIGHT ); 
            //Sets direction
            direction = ( RIGHTwheel.Direction|LEFTwheel.Direction);
            SetDirection(direction); 
            //Sets PWM values
            SetSpeed(RIGHTwheel.PIDoutput, RIGHTWHEEL); //Left Motor
            SetSpeed(LEFTwheel.PIDoutput, LEFTWHEEL); //Right Motor
        }     
    }
}






void setup(void)
{
    
    //CONFIGURES ALL PIN I/O
    ConfigIO();
    PIDinitialise(); 
    
 
    /*TURN OFF ALL INTERRUPTS TO BE SAFE*/
    INTCON = 0;
    PIR1 = 0;
    
    //peripheral interrupts
    PIE1bits.RCIE = 1;  //Going to be receiving
    INTCONbits.TMR0IE = 1; //Timer0 overflow    
    
    //EXTERNAL INTERRUPT CONFIGS AND SETUPS
    INTCON2bits.INTEDG1 = 1;    //Rising edge
    INTCON2bits.INTEDG2 = 1;
    INTCON3bits.INT1IP = 1;
    INTCON3bits.INT2IP = 1;
    INTCON3bits.INT1IE = 1;
    INTCON3bits.INT2IE = 1;
    
    //assign priorities, most things are going to be low
    IPR1bits.RCIP = 0;  //low priority
    INTCON2bits.TMR0IP = 1; //high priority for handshake
    
    //Allow interrupt priority
    RCONbits.IPEN = 1;
    
          //Config the PWM for Motors
    ConfigPWM();  
    
    //Enable the timer in 16 bit
    T0CON = 0x88;   

    //Reactivate interrupts
    INTCONbits.GIEH = 1;
    INTCONbits.GIEL = 1;

}
/* 
 * File:   IoDefs.h
 * Author: Tristan James Hall of House Gilpin
 *
 * Created on 19 October 2015, 5:43 PM
 */

#ifndef IODEFS_H
#define	IODEFS_H

/*Define all constants*/

/*Define functions*/
void ConfigIO(void);

#endif	/* IODEFS_H */

